import React, { useState, useEffect } from 'react';
import axios from 'axios';

const TrainListPage = ({ onTrainClick }) => {
  const [trains, setTrains] = useState([]);

  useEffect(() => {
    axios
      .get('http://localhost:8000/Trains')
      .then((response) => {
        setTrains(response.data);
      })
      .catch((error) => {
        console.log(error);
      });
  }, []);

  return (
    <div>
      <h1>Train List</h1>
      <ul>
        {trains.map((train) => (
          <li key={train.trainNumber} onClick={() => onTrainClick(train.trainNumber)}>
            {train.trainName}
          </li>
        ))}
      </ul>
    </div>
  );
};

export default TrainListPage;
